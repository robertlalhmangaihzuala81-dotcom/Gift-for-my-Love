// --- 1. Your Custom 3 Words Only ---
const sweetWords = [
  "I miss you❤️",
  "I love you💖",
  "You're my favorite person 🌸"
];

let wordIndex = 0;
let isAnimating = false;

// --- 2. Web Audio Synthesizer ---
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

function playChime() {
  try {
    const freqs = [523.25, 659.25, 783.99, 1046.50];
    freqs.forEach((f, i) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, audioCtx.currentTime + i * 0.08);
      gain.gain.setValueAtTime(0.06, audioCtx.currentTime + i * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + i * 0.08 + 0.35);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(audioCtx.currentTime + i * 0.08);
      osc.stop(audioCtx.currentTime + i * 0.08 + 0.35);
    });
  } catch(e) {}
}

// --- 3. Three.js Scene Setup ---
let scene, camera, renderer, controls;
let giftGroup, lidPivot;
let particles = [];
let raycaster, mouse;

function init3D() {
  const container = document.getElementById('three-container');

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 2.8, 5.5);

  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  container.appendChild(renderer.domElement);

  // OrbitControls for 360 rotation
  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.05;
  controls.maxPolarAngle = Math.PI / 2 + 0.1;
  controls.minDistance = 3;
  controls.maxDistance = 9;

  // Cinematic Studio Lighting
  const ambientLight = new THREE.AmbientLight(0xffd5e5, 0.8);
  scene.add(ambientLight);

  const mainLight = new THREE.DirectionalLight(0xffffff, 1.8);
  mainLight.position.set(5, 8, 5);
  mainLight.castShadow = true;
  scene.add(mainLight);

  const rimLight = new THREE.DirectionalLight(0xff0055, 1.2);
  rimLight.position.set(-5, 3, -5);
  scene.add(rimLight);

  giftGroup = new THREE.Group();
  scene.add(giftGroup);

  // --- Darker Luxury Velvet Material ---
  const outerMat = new THREE.MeshStandardMaterial({
    color: 0x6e001e, // Deep burgundy/crimson velvet
    roughness: 0.4,
    metalness: 0.15,
    side: THREE.DoubleSide
  });

  const innerVelvetMat = new THREE.MeshStandardMaterial({
    color: 0x1a0007,
    roughness: 0.9,
    metalness: 0.0
  });

  // --- Metallic Gold Ribbon Material ---
  const ribbonMat = new THREE.MeshStandardMaterial({
    color: 0xffd700,
    roughness: 0.15,
    metalness: 0.9
  });

  // --- BUILD HOLLOW BOX BASE ---
  const size = 1.8;
  const height = 1.4;
  const t = 0.06;

  const baseGroup = new THREE.Group();

  // Bottom Floor
  const bottomGeo = new THREE.BoxGeometry(size, t, size);
  const bottomMesh = new THREE.Mesh(bottomGeo, outerMat);
  bottomMesh.position.y = -height / 2 + t / 2;
  baseGroup.add(bottomMesh);

  // Interior Velvet Floor
  const innerFloor = new THREE.Mesh(
    new THREE.PlaneGeometry(size - t * 2, size - t * 2),
    innerVelvetMat
  );
  innerFloor.rotation.x = -Math.PI / 2;
  innerFloor.position.y = -height / 2 + t + 0.005;
  baseGroup.add(innerFloor);

  // 4 Hollow Side Walls
  const wallGeo = new THREE.BoxGeometry(size, height - t, t);
  const sideGeo = new THREE.BoxGeometry(t, height - t, size - t * 2);

  const frontWall = new THREE.Mesh(wallGeo, outerMat);
  frontWall.position.set(0, 0, size / 2 - t / 2);
  baseGroup.add(frontWall);

  const backWall = new THREE.Mesh(wallGeo, outerMat);
  backWall.position.set(0, 0, -size / 2 + t / 2);
  baseGroup.add(backWall);

  const leftWall = new THREE.Mesh(sideGeo, outerMat);
  leftWall.position.set(-size / 2 + t / 2, 0, 0);
  baseGroup.add(leftWall);

  const rightWall = new THREE.Mesh(sideGeo, outerMat);
  rightWall.position.set(size / 2 - t / 2, 0, 0);
  baseGroup.add(rightWall);

  // Outer Gold Ribbons
  const ribV = new THREE.Mesh(new THREE.BoxGeometry(0.24, height, t + 0.02), ribbonMat);
  ribV.position.set(0, 0, size / 2);
  baseGroup.add(ribV);

  const ribH = new THREE.Mesh(new THREE.BoxGeometry(t + 0.02, height, 0.24), ribbonMat);
  ribH.position.set(size / 2, 0, 0);
  baseGroup.add(ribH);

  giftGroup.add(baseGroup);

  // --- BUILD HINGED HOLLOW LID ---
  lidPivot = new THREE.Group();
  lidPivot.position.set(0, height / 2, -size / 2);

  const lidDepth = size + 0.1;
  const lidH = 0.3;

  const lidTopGeo = new THREE.BoxGeometry(lidDepth, t, lidDepth);
  const lidTopMesh = new THREE.Mesh(lidTopGeo, outerMat);
  lidTopMesh.position.set(0, lidH, lidDepth / 2);
  lidPivot.add(lidTopMesh);

  const lidRimFront = new THREE.Mesh(new THREE.BoxGeometry(lidDepth, lidH, t), outerMat);
  lidRimFront.position.set(0, lidH / 2, lidDepth - t / 2);
  lidPivot.add(lidRimFront);

  const lidRimBack = new THREE.Mesh(new THREE.BoxGeometry(lidDepth, lidH, t), outerMat);
  lidRimBack.position.set(0, lidH / 2, t / 2);
  lidPivot.add(lidRimBack);

  const lidRimLeft = new THREE.Mesh(new THREE.BoxGeometry(t, lidH, lidDepth), outerMat);
  lidRimLeft.position.set(-lidDepth / 2 + t / 2, lidH / 2, lidDepth / 2);
  lidPivot.add(lidRimLeft);

  const lidRimRight = new THREE.Mesh(new THREE.BoxGeometry(t, lidH, lidDepth), outerMat);
  lidRimRight.position.set(lidDepth / 2 - t / 2, lidH / 2, lidDepth / 2);
  lidPivot.add(lidRimRight);

  // Cool Metallic Bow & Ribbon Top
  const lidRib1 = new THREE.Mesh(new THREE.BoxGeometry(0.25, t + 0.02, lidDepth + 0.02), ribbonMat);
  lidRib1.position.set(0, lidH + 0.01, lidDepth / 2);
  lidPivot.add(lidRib1);

  const lidRib2 = new THREE.Mesh(new THREE.BoxGeometry(lidDepth + 0.02, t + 0.02, 0.25), ribbonMat);
  lidRib2.position.set(0, lidH + 0.01, lidDepth / 2);
  lidPivot.add(lidRib2);

  const bowKnot = new THREE.Mesh(new THREE.SphereGeometry(0.12, 16, 16), ribbonMat);
  bowKnot.position.set(0, lidH + 0.12, lidDepth / 2);
  lidPivot.add(bowKnot);

  const loopGeo = new THREE.TorusGeometry(0.22, 0.07, 16, 32);
  const loop1 = new THREE.Mesh(loopGeo, ribbonMat);
  loop1.rotation.y = Math.PI / 4;
  loop1.position.set(-0.15, lidH + 0.18, lidDepth / 2 - 0.12);
  lidPivot.add(loop1);

  const loop2 = new THREE.Mesh(loopGeo, ribbonMat);
  loop2.rotation.y = -Math.PI / 4;
  loop2.position.set(0.15, lidH + 0.18, lidDepth / 2 + 0.12);
  lidPivot.add(loop2);

  giftGroup.add(lidPivot);

  // Sparkles
  createParticles();

  raycaster = new THREE.Raycaster();
  mouse = new THREE.Vector2();

  window.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('resize', onWindowResize);
}

// Particle Engine
function createParticles() {
  const pGeo = new THREE.SphereGeometry(0.035, 8, 8);
  const pMat = new THREE.MeshBasicMaterial({ color: 0xff6584, transparent: true });

  for (let i = 0; i < 35; i++) {
    const p = new THREE.Mesh(pGeo, pMat);
    p.visible = false;
    scene.add(p);
    particles.push({ mesh: p, vx: 0, vy: 0, vz: 0, life: 0 });
  }
}

function burstParticles() {
  particles.forEach(p => {
    p.mesh.position.set(0, 0.2, 0);
    p.mesh.visible = true;
    p.vx = (Math.random() - 0.5) * 0.06;
    p.vy = Math.random() * 0.07 + 0.03;
    p.vz = (Math.random() - 0.5) * 0.06;
    p.life = 1.0;
  });
}

// --- 4. Tap Detection & Animation ---
let pointerStartX = 0;
let pointerStartY = 0;

function onPointerDown(e) {
  pointerStartX = e.clientX;
  pointerStartY = e.clientY;
  window.addEventListener('pointerup', onPointerUp, { once: true });
}

function onPointerUp(e) {
  const distX = Math.abs(e.clientX - pointerStartX);
  const distY = Math.abs(e.clientY - pointerStartY);

  if (distX < 6 && distY < 6 && !isAnimating) {
    mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObjects(giftGroup.children, true);

    if (intersects.length > 0) {
      triggerOpenSequence();
    }
  }
}

function triggerOpenSequence() {
  isAnimating = true;
  playChime();
  burstParticles();

  const wordElem = document.getElementById('sweet-word');
  const wordContainer = document.getElementById('word-container');
  const tapHint = document.getElementById('tap-hint');

  tapHint.style.opacity = '0';
  wordElem.innerText = sweetWords[wordIndex];
  wordContainer.classList.remove('hidden');

  wordIndex = (wordIndex + 1) % sweetWords.length;

  let startTime = performance.now();
  function openLid(now) {
    let progress = Math.min((now - startTime) / 600, 1);
    lidPivot.rotation.x = -progress * 2.1;

    if (progress < 1) {
      requestAnimationFrame(openLid);
    } else {
      wordContainer.classList.add('show');
      setTimeout(closeBoxAndReset, 3000);
    }
  }
  requestAnimationFrame(openLid);
}

function closeBoxAndReset() {
  const wordContainer = document.getElementById('word-container');
  const tapHint = document.getElementById('tap-hint');

  wordContainer.classList.remove('show');

  setTimeout(() => {
    wordContainer.classList.add('hidden');

    let startTime = performance.now();
    function closeLid(now) {
      let progress = Math.min((now - startTime) / 500, 1);
      lidPivot.rotation.x = -2.1 + progress * 2.1;

      if (progress < 1) {
        requestAnimationFrame(closeLid);
      } else {
        lidPivot.rotation.x = 0;
        tapHint.style.opacity = '1';
        isAnimating = false;
      }
    }
    requestAnimationFrame(closeLid);
  }, 400);
}

// Render Loop
function animate() {
  requestAnimationFrame(animate);
  controls.update();

  particles.forEach(p => {
    if (p.mesh.visible) {
      p.mesh.position.x += p.vx;
      p.mesh.position.y += p.vy;
      p.mesh.position.z += p.vz;
      p.life -= 0.02;
      p.mesh.material.opacity = p.life;
      if (p.life <= 0) p.mesh.visible = false;
    }
  });

  renderer.render(scene, camera);
}

function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

init3D();
animate();